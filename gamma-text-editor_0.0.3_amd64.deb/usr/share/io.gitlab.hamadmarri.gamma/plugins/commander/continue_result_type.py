

class ContinueResultType:
		NEXT = 0
		STRICT = 1
		SOFT = 2