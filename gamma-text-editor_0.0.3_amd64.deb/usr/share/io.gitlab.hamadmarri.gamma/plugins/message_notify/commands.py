

def set_commands(plugin):
	pass
	
